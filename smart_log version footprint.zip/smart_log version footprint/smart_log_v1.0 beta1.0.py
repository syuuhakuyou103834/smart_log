import os
import re
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="matplotlib")

import matplotlib as mpl
mpl.rcParams['font.family'] = 'Microsoft YaHei'  # 微软雅黑
mpl.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


class LogAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("日志数据分析工具 v2.0")
        self.root.geometry("1200x800")
        
        # 初始化变量
        self.selected_folder = tk.StringVar()
        self.start_time = tk.StringVar()
        self.end_time = tk.StringVar()
        self.selected_param = tk.StringVar()
        self.file_pattern = re.compile(r"^\d{10}\.csv$")
        self.file_cache = {}
        self.last_scan_folder = ""

        # 创建界面组件
        self.create_widgets()
        
        # 初始化绘图区域
        self.figure = plt.figure(figsize=(10, 5))
        self.canvas = FigureCanvasTkAgg(self.figure, master=self.root)
        self.plot_widget = self.canvas.get_tk_widget()
        self.plot_widget.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True)

        root.protocol("WM_DELETE_WINDOW", self.on_close)  # 添加关闭协议


    def create_widgets(self):
        # 菜单栏
        menubar = tk.Menu(self.root, 
                        font=("微软雅黑", 12),
                        borderwidth=2,
                        relief="raised")
        
        file_menu = tk.Menu(menubar, 
                          tearoff=0,
                          font=("微软雅黑", 11))
        file_menu.add_command(label="24小时Log分析", 
                            command=self.select_folder)
        menubar.add_cascade(label="文件", menu=file_menu)
        self.root.config(menu=menubar)

        # 控制面板
        control_frame = ttk.LabelFrame(self.root, text="分析参数")
        control_frame.pack(padx=10, pady=5, fill=tk.X)

        # 文件夹选择
        ttk.Label(control_frame, text="日志目录:").grid(row=0, column=0, padx=5, sticky="w")
        ttk.Entry(control_frame, textvariable=self.selected_folder, width=40).grid(row=0, column=1)
        ttk.Button(control_frame, text="浏览...", command=self.select_folder).grid(row=0, column=2, padx=5)

        # 时间范围选择（已修改格式标签）
        ttk.Label(control_frame, text="起始时间 (mmddhhmm):").grid(row=1, column=0, padx=5, sticky="w")
        ttk.Entry(control_frame, textvariable=self.start_time, width=15).grid(row=1, column=1, sticky="w")
        ttk.Label(control_frame, text="结束时间 (mmddhhmm):").grid(row=1, column=2, padx=5, sticky="w")
        ttk.Entry(control_frame, textvariable=self.end_time, width=15).grid(row=1, column=3, sticky="w")
        
        # 添加时间格式示例（新增）
        example_label = ttk.Label(control_frame, 
                                text="示例：02251430 = 2月25日14:30",
                                font=("微软雅黑", 9),
                                foreground="#666666")
        example_label.grid(row=1, column=4, padx=10, sticky="w")

        # 参数选择
        ttk.Label(control_frame, text="参数选择:").grid(row=2, column=0, padx=5, sticky="w")
        self.param_combobox = ttk.Combobox(control_frame, textvariable=self.selected_param, state="readonly")
        self.param_combobox.grid(row=2, column=1, sticky="w", pady=5)

        # 分析按钮
        ttk.Button(control_frame, text="开始分析", command=self.analyze_data).grid(row=2, column=3, padx=10)

    def select_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.selected_folder.set(folder)
            self.load_parameters()

    def load_parameters(self):
        """获取第一个文件的参数列表"""
        folder = self.selected_folder.get()
        try:
            for filename in os.listdir(folder):
                if self.file_pattern.match(filename):
                    file_path = os.path.join(folder, filename)
                    with open(file_path, 'r', encoding='utf-8') as f:
                        headers = f.readline().strip().split(',')
                        self.param_combobox['values'] = headers
                        if headers:
                            self.selected_param.set(headers[0])
                        return
        except Exception as e:
            messagebox.showerror("文件错误", f"读取参数失败：{str(e)}")

    def analyze_data(self):
        if not self.validate_inputs():
            return

        try:
            start_dt, end_dt = self.parse_time_range()
            df = self.load_time_range_data(start_dt, end_dt)
            self.plot_data(df, self.selected_param.get())
        except Exception as e:
            messagebox.showerror("分析错误", str(e))

import os
import re
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="matplotlib")

import matplotlib as mpl
mpl.rcParams['font.family'] = 'Microsoft YaHei'  # 微软雅黑
mpl.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题




class LogAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("日志数据分析工具 v2.0")
        self.root.geometry("1200x800")

        self.current_ax = None  # 新增: 用于保存当前的axes对象
        
        # 初始化变量
        self.selected_folder = tk.StringVar()
        self.start_time = tk.StringVar()
        self.end_time = tk.StringVar()
        self.selected_param = tk.StringVar()
        self.file_pattern = re.compile(r"^\d{10}\.csv$")
        self.file_cache = {}
        self.last_scan_folder = ""

        # 字体和样式配置（新增）
        self.ctrl_font = ('Microsoft YaHei', 18)  # 统一控制面板字体
        self.label_width = 15  # 标签宽度

        # 创建界面组件
        self.create_widgets()
        
        # 初始化绘图区域
        self.figure = plt.figure(figsize=(10, 5))
        self.canvas = FigureCanvasTkAgg(self.figure, master=self.viz_frame)  # 修改父容器
        self.plot_widget = self.canvas.get_tk_widget()
        self.plot_widget.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        root.protocol("WM_DELETE_WINDOW", self.on_close)

    def create_widgets(self):
        # 创建主容器框架（新增）
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        # ================== 左侧控制面板（新布局）==================
        self.control_panel = ttk.LabelFrame(self.main_frame, text="参数分析",
                                          padding=(10, 5))
        self.control_panel.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)

        # ================== 右侧可视化区域（新布局）==================
        self.viz_frame = ttk.Frame(self.main_frame)
        self.viz_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # 菜单栏（保持在主窗口顶部）
        menubar = tk.Menu(self.root, font=self.ctrl_font)
        file_menu = tk.Menu(menubar, tearoff=0, font=self.ctrl_font)
        file_menu.add_command(label="24小时Log分析", 
                            command=self.select_folder)
        menubar.add_cascade(label="文件", menu=file_menu)
        self.root.config(menu=menubar)

        # 构建控制面板内容
        self.setup_control_panel()
    

    def setup_control_panel(self):
        """重构后的控制面板布局"""
        # 整体框架宽度调整 (新增)
        self.control_panel.config(width=240)  # 将宽度设为原始尺寸的一半（根据实际情况调整具体数值）

        # ====== 日志目录区域 ======
        row = 0
        # 日志目录标签和输入框
        ttk.Label(self.control_panel, text="日志目录:", 
                 font=self.ctrl_font, width=self.label_width).grid(row=row, column=0, sticky="ew", pady=3)
        ttk.Entry(self.control_panel, textvariable=self.selected_folder, 
                 font=self.ctrl_font).grid(row=row, column=1, sticky="ew", pady=3)
    
        # 把浏览按钮放到新行（移动并增加columnspan）
        row +=1
        ttk.Button(self.control_panel, text="浏览...", 
                  command=self.select_folder, style='TButton').grid(
                      row=row, column=0, columnspan=2, pady=(0,10), sticky="ew")

        # ====== 时间范围区域 ======
        row +=2
        # 起始时间（在新行开始）
        ttk.Label(self.control_panel, text="起始时间:", 
                 font=self.ctrl_font, width=self.label_width).grid(row=row, column=0, sticky="w", pady=3)
        ttk.Entry(self.control_panel, textvariable=self.start_time, 
                 font=self.ctrl_font, width=10).grid(row=row, column=1, sticky="w", pady=3)
    
        # 结束时间放到下一行
        row +=1
        ttk.Label(self.control_panel, text="结束时间:", 
                 font=self.ctrl_font, width=self.label_width).grid(row=row, column=0, sticky="w", pady=3)
        ttk.Entry(self.control_panel, textvariable=self.end_time, 
                 font=self.ctrl_font, width=10).grid(row=row, column=1, sticky="w", pady=3)

        # ====== 后续元素下移 ======
        row +=1
        example_label = ttk.Label(self.control_panel, 
                                text="示例：02251430 = 2月25日14:30",
                                font=('Microsoft YaHei', 15),
                                foreground="#666666")
        example_label.grid(row=row, column=0, columnspan=2, pady=5, sticky="w")

        row +=2
        ttk.Label(self.control_panel, text="选择主要参数:", 
                 font=self.ctrl_font, width=self.label_width).grid(row=row, column=0, sticky="w", pady=5)
        self.param_combobox = ttk.Combobox(self.control_panel, 
                                         textvariable=self.selected_param,
                                         font=self.ctrl_font,
                                         state="readonly")
        self.param_combobox.grid(row=row, column=1, columnspan=1, sticky="ew", pady=5)

        # 分析按钮区域
        row +=1
        button_frame = ttk.Frame(self.control_panel)
        button_frame.grid(row=row, column=0, columnspan=2, pady=10, sticky="e")
        ttk.Button(button_frame, text="开始作图", 
                  command=self.analyze_data, style='Accent.TButton').pack(side=tk.RIGHT)

        #  调整列权重（新增列1的拉伸）
        self.control_panel.columnconfigure(0, weight=0)
        self.control_panel.columnconfigure(1, weight=1)  # 让输入框可以拉伸




    
    def select_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.selected_folder.set(folder)
            self.load_parameters()

    def load_parameters(self):
        """获取第一个文件的参数列表"""
        folder = self.selected_folder.get()
        try:
            for filename in os.listdir(folder):
                if self.file_pattern.match(filename):
                    file_path = os.path.join(folder, filename)
                    with open(file_path, 'r', encoding='utf-8') as f:
                        headers = f.readline().strip().split(',')
                        self.param_combobox['values'] = headers
                        if headers:
                            self.selected_param.set(headers[0])
                        return
        except Exception as e:
            messagebox.showerror("文件错误", f"读取参数失败：{str(e)}")

    def analyze_data(self):
        if not self.validate_inputs():
            return

        try:
            start_dt, end_dt = self.parse_time_range()
            df = self.load_time_range_data(start_dt, end_dt)
            self.plot_data(df, self.selected_param.get())


        except Exception as e:
            messagebox.showerror("分析错误", str(e))



    def validate_inputs(self):
        errors = []
        if not self.selected_folder.get():
            errors.append("请选择日志目录")
        if not self.start_time.get():
            errors.append("请输入起始时间")
        if not self.end_time.get():
            errors.append("请输入结束时间")
        if not self.selected_param.get():
            errors.append("请选择分析参数")
        
        if errors:
            messagebox.showwarning("输入不完整", "\n".join(errors))
            return False
        return True

    def parse_time_range(self):
        """解析新时间格式mmddhhmm"""
        def parse_time(s):
            try:
                # 验证输入格式
                if len(s) != 8 or not s.isdigit():
                    raise ValueError("必须为8位数字（如02251430）")
                
                mm = int(s[0:2])
                dd = int(s[2:4])
                hh = int(s[4:6])
                mi = int(s[6:8])

                current_year = datetime.now().year
                dt = datetime(current_year, mm, dd, hh, mi)
                
                # 检查datetime是否维持原始输入值
                if (dt.month, dt.day, dt.hour, dt.minute) != (mm, dd, hh, mi):
                    raise ValueError("日期时间值不合法")
                return dt
            except ValueError as e:
                raise ValueError(f"无效时间格式: {s} | {str(e)}")

        start_dt = parse_time(self.start_time.get())
        end_dt = parse_time(self.end_time.get())
        
        if start_dt >= end_dt:
            raise ValueError("结束时间必须晚于起始时间")
            
        return start_dt, end_dt

    def load_time_range_data(self, start_dt, end_dt):
        """加载时间范围数据（优化缓存）"""
        if self.selected_folder.get() == self.last_scan_folder:
            date_files = self.file_cache.get(self.selected_folder.get(), {})
        else:
            date_files = self.scan_files(self.selected_folder.get())
        
        all_data = []
        param_index = None
        current_year = datetime.now().year
        
        start_ymd = start_dt.strftime("%Y%m%d")
        end_ymd = end_dt.strftime("%Y%m%d")

        for date_str, hours in date_files.items():
            # 优化日期范围筛选
            if date_str < start_ymd or date_str > end_ymd:
                continue

            for hour in hours:
                filename = f"{date_str}{hour}.csv"
                file_path = os.path.join(self.selected_folder.get(), filename)
                
                try:
                     with open(file_path, 'r', encoding='utf-8') as f:
                          headers = f.readline().strip().split(',')
                          f.readline()  # 跳过单位行
        
                          # 获取参数索引
                          selected_param = self.selected_param.get()
                          if param_index is None:
                             param_index = headers.index(selected_param)
        
                          # 从文件名提取日期部分
                          file_date_str = filename[:8]  # 文件名中的yyyymmdd
                          base_date = datetime.strptime(file_date_str, "%Y%m%d")
        
                          for line in f:
                              values = line.strip().split(',')
                              # 合并文件名中的日期和时间列的时间部分
                              raw_time = values[0]
            
                              # 时间格式转换逻辑
                              if raw_time.count(":") == 3:
                                 time_parts = raw_time.split(":")
                              # 转换格式：hh:mm:ss.fff
                                 formatted_time = f"{time_parts[0]}:{time_parts[1]}:{time_parts[2]}.{time_parts[3]}"
                              else:
                                  formatted_time = raw_time  # 兼容非毫秒格式
            
                              # 组合完整时间
                              try:
                                  time_with_date = datetime.combine(
                                     base_date,
                                     datetime.strptime(formatted_time, "%H:%M:%S.%f").time()
                                  )
                              except ValueError:
                                   time_with_date = datetime.combine(
                                      base_date,
                                      datetime.strptime(formatted_time, "%H:%M:%S").time()
                                   )
            
                              # 验证并存储数据
                              if start_dt <= time_with_date <= end_dt:
                                 all_data.append({
                                    'Timestamp': time_with_date,
                                    'Value': float(values[param_index])
                                  })
                except FileNotFoundError:
                    continue
                except Exception as e:
                    raise RuntimeError(f"文件{filename}读取错误: {str(e)}")

        return pd.DataFrame(all_data)

    def scan_files(self, folder):
        """扫描文件夹并缓存结果"""
        date_files = {}
        if folder == self.last_scan_folder and folder in self.file_cache:
            return self.file_cache[folder]
        
        for filename in os.listdir(folder):
            if self.file_pattern.match(filename):
                date_str = filename[:8]  # yyyymmdd
                hour_str = filename[8:10]
                date_files.setdefault(date_str, []).append(hour_str)
        
        self.file_cache[folder] = date_files
        self.last_scan_folder = folder
        return date_files

    def plot_data(self, df, param_name):
        if df.empty:
            messagebox.showwarning("无数据", "所选时间范围没有匹配数据")
            return

        self.figure.clear()
        ax = self.figure.add_subplot(111)
        
        # 增强可视化样式
        ax.plot(df['Timestamp'], df['Value'], 
               marker='o', 
               markersize=4,
               linewidth=1.5,
               color='#1f77b4',
               alpha=0.8)
               
        ax.set_title(f"{param_name} 时序分析\n({self.start_time.get()} 至 {self.end_time.get()})", 
                    fontsize=20, pad=15)
        ax.set_xlabel("时间", fontsize=20, labelpad=10)
        ax.set_ylabel(param_name, fontsize=20, labelpad=10)
        ax.grid(True, linestyle=':', alpha=0.7)
        ax.tick_params(axis='both', labelsize=20)

        
        # 优化时间刻度
        self.figure.autofmt_xdate(rotation=30)
        self.canvas.draw()
        
        ax = self.figure.add_subplot(111)
        self.current_ax = ax  # 保存当前Axes对象

        self.canvas.draw()
    
         # 绑定双击事件到Y轴标签
        def on_dblclick(event):
            if event.inaxes == self.current_ax:
               if event.ydata is None:  # 点击在Y轴区域
                   self.show_yaxis_config()
            self.canvas.mpl_connect('button_press_event', on_dblclick)
    

    def show_yaxis_config(self):
        if not self.current_ax:
            return
    
        current_ylim = self.current_ax.get_ylim()
        dialog = AxisConfigDialog(self.root, current_ylim)
        self.root.wait_window(dialog)
    
        if hasattr(dialog, 'result'):
            ymin, ymax, step = dialog.result
            self.current_ax.set_ylim(ymin, ymax)
        
            # 设置自定义刻度（如果有指定step）
            if step:
                from matplotlib.ticker import MultipleLocator
                self.current_ax.yaxis.set_major_locator(MultipleLocator(step))
        
            self.canvas.draw()  # 立即刷新显示

    def on_close(self):
        plt.close('all')  # 关闭所有matplotlib图形
        self.root.destroy()  # 彻底销毁窗口

    

class AxisConfigDialog(tk.Toplevel):
    def __init__(self, parent, current_ylim):
        super().__init__(parent)
        self.title("Y轴配置")
        self.current_ylim = current_lim = (round(current_ylim[0],2), 
                                         round(current_ylim[1],2))
        self.build_ui()
    
    def build_ui(self):
        ttk.Label(self, text="最小值:").grid(row=0, column=0, padx=5, pady=5)
        self.min_entry = ttk.Entry(self)
        self.min_entry.insert(0, str(self.current_lim[0]))
        self.min_entry.grid(row=0, column=1)

        ttk.Label(self, text="最大值:").grid(row=1, column=0, padx=5, pady=5)
        self.max_entry = ttk.Entry(self)
        self.max_entry.insert(0, str(self.current_lim[1]))
        self.max_entry.grid(row=1, column=1)

        ttk.Label(self, text="刻度间隔:").grid(row=2, column=0, padx=5, pady=5)
        self.step_entry = ttk.Entry(self)
        self.step_entry.grid(row=2, column=1)

        btn_frame = ttk.Frame(self)
        btn_frame.grid(row=3, columnspan=2, pady=10)
        ttk.Button(btn_frame, text="确定", command=self.on_confirm).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="取消", command=self.destroy).pack(side=tk.LEFT)

    def on_confirm(self):
        try:
            ymin = float(self.min_entry.get())
            ymax = float(self.max_entry.get())
            step = float(self.step_entry.get()) if self.step_entry.get() else None
            if ymin >= ymax:
                raise ValueError("最小值必须小于最大值")
            if step and step <=0:
                raise ValueError("间隔必须为正数")
            
            self.result = (ymin, ymax, step)
            self.destroy()
        except ValueError as e:
            messagebox.showerror("输入错误", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    
    # 统一配置所有组件样式（新增LabelFrame样式）
    style = ttk.Style()
    style.theme_use('clam')
    # 配置LabelFrame标题字体（新增部分）
    style.configure('TLabelframe', 
                   font=('Microsoft YaHei', 20),
                   relief='raised')
    style.configure('TLabelframe.Label',
                   font=('Microsoft YaHei', 20, 'bold'),
                   foreground='#2c3e50')  # 标题文字颜色
    
    # 原有按钮样式配置
    style.configure('TButton', font=('Microsoft YaHei', 18), padding=5)
    style.configure('Accent.TButton', 
                   font=('Microsoft YaHei', 18, 'bold'), 
                   foreground='white', 
                   background='#4a90e2')
    
     # 新增 Combobox 字体配置（关键修改部分）
    style.configure('TCombobox',
                    font=('Microsoft YaHei', 18),            # 输入框字体
                    fieldbackground='white',                 # 输入框背景色（可选）
                    selectbackground='#4a90e2')              # 选中项背景色（可选）

    # 下拉菜单列表项字体需要单独配置（部分主题支持）
    style.configure('TCombobox.Listbox',
                    font=('Microsoft YaHei', 18),            # 下拉列表字体  
                    relief='flat')                           # 去除边框（可选）
    
    # 如果使用 "clam" 主题还需以下偏移调整（预防文字截断）
    style.configure('TCombobox', postoffset=(0,0,0,5))       # 调整下拉框底部间距
    
    app = LogAnalyzerApp(root)
    root.mainloop()

